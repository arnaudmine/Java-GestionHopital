package View;


import Controller.ApplicationController;
import Model.Patient;
import Utils.Verification;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class CreatePatientPanel extends JPanel {

    Container mainContainer;

    public CreatePatientPanel(Container mainContainer){

        this.mainContainer = mainContainer;

        setLayout(new BorderLayout());
        add(new titlePatientPanel(), BorderLayout.NORTH);
        FormPatientPanel formPatientPanel = new FormPatientPanel();
        add(formPatientPanel, BorderLayout.CENTER);
        add(new ButtonPatientPanel(formPatientPanel), BorderLayout.SOUTH);

    }

    public class FormPatientPanel extends JPanel {
        private JLabel arrivalDateLabel, adressLabel,lastNameLabel,firstNameLabel, diseaseLabel, billLabel, nurseLabel, bedroomLabel, emailLabel, insuranceLabel;
        private JTextField arrivalDateTextField, adressTextField, lastNameTextField, firstNameTextField, diseaseTextField, billTextField, emailTextField, insuranceTextField;
        private JComboBox nurseCB, bedroomCB;
        private ApplicationController controller;

        public FormPatientPanel() {
            setLayout(new GridLayout(9, 2, 15, 35));

            try {
                controller = new ApplicationController();

                //adress
                adressLabel = new JLabel("Adresse du patient : ");
                adressLabel.setHorizontalAlignment(4);
                add(adressLabel);
                adressTextField = new JTextField();
                add(adressTextField);

                //date
                arrivalDateLabel = new JLabel("Date d'arrivée : ");
                arrivalDateLabel.setHorizontalAlignment(4);
                add(arrivalDateLabel);

                Calendar calendar = Calendar.getInstance();
                Date date = calendar.getTime();

                SimpleDateFormat fmt = new SimpleDateFormat("dd-MMM-yyyy");
                String dateFormated = fmt.format(date.getTime());
                arrivalDateTextField = new JTextField(dateFormated);
                arrivalDateTextField.setEditable(false);
                add(arrivalDateTextField);

                //LastName
                lastNameLabel = new JLabel("Nom du patient : ");
                lastNameLabel.setHorizontalAlignment(4);
                add(lastNameLabel);

                lastNameTextField = new JTextField();
                add(lastNameTextField);

                //firstName
                firstNameLabel = new JLabel("Prénom : ");
                firstNameLabel.setHorizontalAlignment(4);
                add(firstNameLabel);

                firstNameTextField = new JTextField();
                add(firstNameTextField);

                //disease(s)
                diseaseLabel = new JLabel("Maladie(s) du patient : ");
                diseaseLabel.setHorizontalAlignment(4);
                add(diseaseLabel);

                diseaseTextField = new JTextField();
                add(diseaseTextField);

                //Nurse
                nurseLabel = new JLabel("Infirmier(e) : ");
                nurseLabel.setHorizontalAlignment(4);
                add(nurseLabel);

                nurseCB = new JComboBox();
                nurseCB.setMaximumRowCount(5);
                fillNurseCombobox(controller.getAllNurses());
                add(nurseCB);

                //bedroom
                bedroomLabel = new JLabel("Numéro de la Chambre : ");
                bedroomLabel.setHorizontalAlignment(4);
                add(bedroomLabel);

                bedroomCB = new JComboBox();
                bedroomCB.setMaximumRowCount(3);
                fillBedroomCombobox(controller.getAllAvailableBedroom());
                add(bedroomCB);

                //email
                emailLabel = new JLabel("E-mail du patient : ");
                emailLabel.setHorizontalAlignment(4);
                add(emailLabel);
                emailTextField = new JTextField();
                add(emailTextField);

                //InsuranceCompany
                insuranceLabel = new JLabel("Assurance médicale du patient : ");
                insuranceLabel.setHorizontalAlignment(4);
                add(insuranceLabel);

                insuranceTextField = new JTextField();
                add(insuranceTextField);
            }
            catch (Exception e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            }
        }

        public void fillNurseCombobox(ArrayList<String> nursesList) {
            for(String nurse : nursesList) {
                nurseCB.addItem(nurse);
            }
        }

        public void fillBedroomCombobox(ArrayList<Integer> bedroomsList) {
            for(Integer bedroom : bedroomsList) {
                bedroomCB.addItem(bedroom);
            }
        }

        public JTextField getLastNameTextField() {
            return lastNameTextField;
        }

        public JTextField getFirstNameTextField() {
            return firstNameTextField;
        }

        public JTextField getAdressTextField() {
            return adressTextField;
        }

        public JTextField getDiseaseTextField() {
            return diseaseTextField;
        }

        public JComboBox getNurseCB() {
            return nurseCB;
        }

        public JComboBox getBedroomCB() {
            return bedroomCB;
        }

        public JTextField getEmailTextField() {
            return emailTextField;
        }

        public JTextField getInsuranceTextField() {
            return insuranceTextField;
        }
    }

    public class titlePatientPanel extends JPanel{
        private JLabel title;

        public titlePatientPanel(){
            setBackground(Color.LIGHT_GRAY);
            setLayout(new FlowLayout());

            title = new JLabel("Création d'un nouveau patient : ");
            title.setFont(new Font(Font.DIALOG,Font.BOLD,20));
            add(title);
        }
    }

    public class ButtonPatientPanel extends JPanel {

        private FormPatientPanel formPatientPanel;

        public ButtonPatientPanel(FormPatientPanel formPatientPanel){
            setBackground(Color.LIGHT_GRAY);

            this.formPatientPanel = formPatientPanel;


            setLayout(new FlowLayout());
            JButton addPatientButton = new JButton("Ajouter le patient");
            addPatientButton.addActionListener(new AddPatientListener());
            add(addPatientButton);

            JButton resetPanel = new JButton("Réinitialiser");
            add(resetPanel);
            add(new BackButton(mainContainer));
        }


        public class AddPatientListener implements ActionListener{

            public void actionPerformed(ActionEvent e) {

                String lastName = formPatientPanel.getLastNameTextField().getText();
                String firstName = formPatientPanel.getFirstNameTextField().getText();

                String address = formPatientPanel.getAdressTextField().getText();
                String disease = formPatientPanel.getDiseaseTextField().getText();
                String bedroom = formPatientPanel.getBedroomCB().getSelectedItem().toString();
                String email = "";

                if(!formPatientPanel.getEmailTextField().getText().equals("")) {
                    email = formPatientPanel.getEmailTextField().getText();
                }

                String insurance = formPatientPanel.getInsuranceTextField().getText();
                String infoInfirmiere = formPatientPanel.getNurseCB().getSelectedItem().toString();


                try {
                    ApplicationController controller = new ApplicationController();
                    Patient patient = Verification.createPatient(lastName, firstName, address,disease, bedroom, email, insurance, infoInfirmiere);
                    controller.addPatient(patient);
                    System.out.println("test a ne pas mettre si erreur dans DB");
                }
                catch(Exception exception){
                    JOptionPane.showMessageDialog(null, exception.getMessage(), "Erreur(s)", JOptionPane.ERROR_MESSAGE);
                }

            }
        }
    }
}