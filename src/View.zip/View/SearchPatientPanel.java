package View;

import Controller.ApplicationController;
import Controller.DataAccess;
import Model.HeadDepartment;
import Model.QueryResultPatient;
import Utils.StringManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class SearchPatientPanel extends JPanel {
    public SearchPatientPanel() {
        setLayout(new BorderLayout());
        ResultPanel resultPanel = new ResultPanel();
        ResearchPanel researchPanel = new ResearchPanel(resultPanel);
        researchPanel.setPreferredSize(new Dimension(0,100));
        add(researchPanel, BorderLayout.NORTH);
        add(resultPanel, BorderLayout.CENTER);
    }

    public class ResearchPanel extends JPanel {
        private JLabel label;
        private JButton researchButton;
        private JComboBox headsDepartmentCombobox;
        private ApplicationController controller;
        private ResultPanel resultPanel;

        public ResearchPanel(ResultPanel resultPanel) {
            this.resultPanel = resultPanel;
            setLayout(new FlowLayout(FlowLayout.CENTER));
            label = new JLabel("Chefs de service");
            add(label);

            try {
                controller = new ApplicationController();

                // combobox
                headsDepartmentCombobox = new JComboBox();
                headsDepartmentCombobox.setMaximumRowCount(3);
                fillCombobox(controller.getAllHeadsDepartmentName());
                add(headsDepartmentCombobox);
            }
            catch(Exception e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            }

            researchButton = new JButton("Rechercher");
            researchButton.addActionListener(new AddSearchPatientListener());
            add(researchButton);

            setBackground(Color.LIGHT_GRAY);

        }

        public JComboBox getHeadsDepartmentCombobox() {
            return headsDepartmentCombobox;
        }

        public void fillCombobox(ArrayList<String> headsDepartmentNameList) {
            for(String headDepartment : headsDepartmentNameList) {
                headsDepartmentCombobox.addItem(headDepartment);
            }
        }

        public class AddSearchPatientListener implements ActionListener{

            public void actionPerformed(ActionEvent e) {
                try{
                    String fullName = getHeadsDepartmentCombobox().getSelectedItem().toString();
                    String id = StringManager.convertFullNameIntoHeadDptID(fullName);
                    System.out.println(fullName + " " + id);
                    ArrayList<QueryResultPatient> result = controller.getPatientByHeadDpt(id);
                    InformationPatientModel informationPatientModel = new InformationPatientModel(result);
                    resultPanel.getTable().setModel(informationPatientModel);
                }
                catch(Exception exception){
                    JOptionPane.showMessageDialog(null,exception.getMessage());
                }
            }
        }
    }

    public class ResultPanel extends JPanel {
        private InformationPatientModel model;
        private JTable table;
        private JScrollPane scrollPane;
        private ApplicationController controller;

        public ResultPanel() {
            setLayout(new BorderLayout());

            try {
                controller = new ApplicationController();
                ArrayList<QueryResultPatient> defaultList = controller.getPatientByHeadDpt("JB");
                model = new InformationPatientModel(defaultList);
                table = new JTable(model);
                scrollPane = new JScrollPane(table);

                add(table.getTableHeader(), BorderLayout.NORTH);
                add(scrollPane, BorderLayout.CENTER);

            }
            catch(Exception e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            }
        }

        public JTable getTable() {
            return table;
        }
    }


}




