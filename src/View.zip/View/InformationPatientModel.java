package View;

import Model.QueryResultPatient;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.GregorianCalendar;

public class InformationPatientModel extends AbstractTableModel {

    private ArrayList<String> columnNames;

    private ArrayList<QueryResultPatient> content;

    public InformationPatientModel(ArrayList<QueryResultPatient> content) {

        columnNames = new ArrayList<>();
        columnNames.add("Numéro de chambre");
        columnNames.add("Nom du patient");
        columnNames.add("Prénom du patient");
        columnNames.add("Date d'arrivée du patient");
        columnNames.add("Nom de l'infirmier");
        columnNames.add("Prénom de l'infirmier");
        this.content = content;
    }

    public String getColumnName(int column){return columnNames.get(column);}

    @Override
    public int getRowCount() {
        return content.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.size();
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        QueryResultPatient result = content.get(rowIndex);
        switch(columnIndex){
            case 0 :
                return result.getChamber();
            case 1 :
                return result.getPatientLastName();
            case 2 :
                return result.getPatientFirstName();
            case 3 :
                return result.getArrivalDate();
            case 4 :
                return result.getNurseLastName();
            case 5 :
                return result.getNurseFirstName();
            default: return null;
        }
    }

    public Class getColumnClass(int column){
        Class c;
        switch (column){
            case 0 :
                c = Integer.class;
                break;
            case 3 :
                c = GregorianCalendar.class;
                break;
            default :
                c = String.class;
                break;
        }
        return c;
    }
}
