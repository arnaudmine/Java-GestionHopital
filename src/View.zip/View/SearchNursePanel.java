package View;

import javax.swing.*;
import java.awt.*;

public class SearchNursePanel extends JPanel {

    public SearchNursePanel(){

        setLayout(new BorderLayout());
        ResearchPanel researchPanel = new ResearchPanel();
        researchPanel.setPreferredSize(new Dimension(0,100));
        add(researchPanel, BorderLayout.NORTH);
        add(new ResultPanel(), BorderLayout.CENTER);
    }

    public class ResearchPanel extends JPanel {
        private JLabel labelDate1;
        private JLabel labelDate2;
        private JSpinner date1;
        private JSpinner date2;
        private JButton researchButton;

        public ResearchPanel() {
            //setLayout(new FlowLayout());

            labelDate1 = new JLabel("Date 1");
            add(labelDate1);

            date1 = new JSpinner(new SpinnerDateModel());
            JSpinner.DateEditor editorDate1 = new JSpinner.DateEditor(date1, "dd/MM/yy");
            date1.setEditor(editorDate1);
            add(date1);

            labelDate2 = new JLabel("Date 2");
            add(labelDate2);

            date2 = new JSpinner(new SpinnerDateModel());
            JSpinner.DateEditor editorDate2 = new JSpinner.DateEditor(date2, "dd/MM/yy");
            date2.setEditor(editorDate2);
            add(date2);

            researchButton = new JButton("Rechercher");

            setBackground(Color.LIGHT_GRAY);
            add(researchButton);
        }
    }


    public class ResultPanel extends JPanel {
        private JTable table;
        private String[] titles = {"Infirmier", "Service", "Chef de service"};
        private Object data[][]={
                {"101","Amit","670000"},
                {"102","Jai","780000"},
                {"101","Sachin","700000"}
        };

        public ResultPanel() {
            setLayout(new BorderLayout());

            table = new JTable(data, titles);
            table.setEnabled(false);

            add(table.getTableHeader(), BorderLayout.NORTH);
            add(table, BorderLayout.CENTER);
        }
    }
}
