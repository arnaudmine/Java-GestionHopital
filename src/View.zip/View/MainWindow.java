package View;

import Model.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class MainWindow extends JFrame {

    private Container mainContainer;
    private JMenuBar menuBar;
    private JMenu consultationMenu, patientMenu, nurseMenu, applicationMenu;
    private JMenuItem searchConsultationItem, searchPatientItem, createPatientItem, modifyPatientItem, searchNurseItem, exitItem, firstPageItem;


    public MainWindow() {
        super("AGH");
        setSize(1200,700);
        setLocationRelativeTo(null);
        mainContainer = this.getContentPane();
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        //MenuBar
        menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        //Consultations
        consultationMenu = new JMenu("Consultations");
        consultationMenu.setMnemonic('c');
        menuBar.add(consultationMenu);

        searchConsultationItem = new JMenuItem("Rechercher");
        searchConsultationItem.addActionListener(new ChangePanelListener(new SearchConsultationPanel(), mainContainer));
        consultationMenu.add(searchConsultationItem);

        //Patient
        patientMenu = new JMenu("Patient");
        patientMenu.setMnemonic('p');
        menuBar.add(patientMenu);

        searchPatientItem = new JMenuItem("Rechercher");
        searchPatientItem.addActionListener(new ChangePanelListener(new SearchPatientPanel(), mainContainer));
        createPatientItem = new JMenuItem("Ajouter un patient");
        createPatientItem.addActionListener(new ChangePanelListener(new CreatePatientPanel(mainContainer), mainContainer));

        Calendar calendar = Calendar.getInstance();
        calendar.set(2018, 11, 31);
        Date time = calendar.getTime();
        GregorianCalendar date = new GregorianCalendar();
        date.setTime(time);
        Patient patientTest = new Patient("02","Mine", "Arnaud", date, "Rue de la Station 3 5030 Beuzet", "Fracture du tibia", 0, "nurseTest", 4, false, "arnaudmine5478@gmail.com","Assurance Medicale Belge" );
        modifyPatientItem = new JMenuItem("Modifier un patient (temp)");
        modifyPatientItem.addActionListener(new ChangePanelListener(new PatientPanel(mainContainer, patientTest), mainContainer));
        patientMenu.add(searchPatientItem);
        patientMenu.add(createPatientItem);
        patientMenu.add(modifyPatientItem);



        //Nurse
        nurseMenu = new JMenu("Infirmier");
        nurseMenu.setMnemonic('i');
        menuBar.add(nurseMenu);

        searchNurseItem = new JMenuItem("Rechercher");
        searchNurseItem.addActionListener(new ChangePanelListener(new SearchNursePanel(), mainContainer));
        nurseMenu.add(searchNurseItem);

        //Application
        applicationMenu = new JMenu("Application");
        applicationMenu.setMnemonic('a');
        menuBar.add(applicationMenu);

        exitItem = new JMenuItem("Fermer l'application");
        exitItem.addActionListener(new ExitListener());
        applicationMenu.add(exitItem);

        firstPageItem = new JMenuItem("Page d'accueil");
        firstPageItem.addActionListener(new ChangePanelListener(new FirstPanel(this.getSize().getWidth()), mainContainer));
        applicationMenu.add(firstPageItem);


        mainContainer.add(new FirstPanel(this.getSize().getWidth()));
        this.setVisible(true);
    }

    public class ExitListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            System.exit(0);
        }
    }
}
