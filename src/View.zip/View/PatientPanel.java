package View;


import Controller.ApplicationController;
import Model.Nurse;
import Model.Patient;

import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class PatientPanel extends JPanel{
    private Container mainContainer;
    private Patient patient;

    public PatientPanel(Container mainContainer, Patient patient){
        this.patient = patient;

        setLayout(new BorderLayout());
        add(new PatientPanel.titlePatientPanel(patient), BorderLayout.NORTH);
        add(new PatientPanel.ButtonPatientPanel(mainContainer), BorderLayout.SOUTH);
        add(new PatientPanel.InformationConsultationPanel(patient), BorderLayout.CENTER);


    }

    public class InformationConsultationPanel extends JPanel {
        private Patient patient;
        private JLabel arrivalDateLabel, adressLabel, diseaseLabel, billLabel, nurseLabel, bedroomLabel, canLeaveLabel, emailLabel, insuranceLabel;
        private JTextField arrivalDateTextField, adressTextField, diseaseTextField, billTextField, emailTextField, insuranceTextField;
        private JComboBox nurseCB, bedroomCB;
        private ApplicationController controller;

        public InformationConsultationPanel(Patient patient){
            setLayout(new GridLayout(9,2,15,35));

            this.patient = patient;

            try {
                controller = new ApplicationController();

                //date
                arrivalDateLabel = new JLabel("Date d'arrivée : ");
                arrivalDateLabel.setHorizontalAlignment(4);
                add(arrivalDateLabel);

                SimpleDateFormat fmt = new SimpleDateFormat("dd-MMM-yyyy");
                String dateFormated = fmt.format(patient.getArrivalDate().getTime());
                arrivalDateTextField = new JTextField(dateFormated);
                arrivalDateTextField.setEditable(false);
                add(arrivalDateTextField);

                //adress
                adressLabel = new JLabel("Adresse du patient : ");
                adressLabel.setHorizontalAlignment(4);
                add(adressLabel);

                adressTextField = new JTextField(patient.getAddress());
                add(adressTextField);

                //disease(s)
                diseaseLabel = new JLabel("Maladie(s) du patient : ");
                diseaseLabel.setHorizontalAlignment(4);
                add(diseaseLabel);

                diseaseTextField = new JTextField(patient.getDisease());
                diseaseTextField.setEditable(false);
                add(diseaseTextField);

                //bill
                billLabel = new JLabel("Facture actuelle du patient : ");
                billLabel.setHorizontalAlignment(4);
                add(billLabel);

                billTextField = new JTextField(String.valueOf(patient.getBill()));
                billTextField.setEditable(false);
                add(billTextField);

                //Nurse
                nurseLabel = new JLabel("Infirmier(e) : ");
                nurseLabel.setHorizontalAlignment(4);
                add(nurseLabel);

                //String[] nurses = {patient.getNurse().getLastName() + " " + patient.getNurse().getFirstName(), "Nom Prénom","Nom Prénom","Nom Prénom","Nom Prénom"};
                nurseCB = new JComboBox();
                nurseCB.setMaximumRowCount(3);
                fillNurseCombobox(controller.getAllNurses());
                add(nurseCB);

                //bedroom
                bedroomLabel = new JLabel("Numéro de la Chambre : ");
                bedroomLabel.setHorizontalAlignment(4);
                add(bedroomLabel);

                String[] bedrooms = {String.valueOf(patient.getBedroom()), "1", "2", "3", "4"};
                bedroomCB = new JComboBox(bedrooms);
                bedroomCB.setSelectedIndex(0);
                bedroomCB.setMaximumRowCount(3);
                add(bedroomCB);

                //canLeave
                canLeaveLabel = new JLabel("Peut quitter l'hôpital");
                canLeaveLabel.setHorizontalAlignment(4);
                add(canLeaveLabel);

                add(new RadioButtonPatientPanel(patient));

                //email

                emailLabel = new JLabel("E-mail du patient : ");
                emailLabel.setHorizontalAlignment(4);
                add(emailLabel);
                emailTextField = new JTextField(patient.getEmail());
                add(emailTextField);

                //InsuranceCompany

                insuranceLabel = new JLabel("Assurance médicale du patient : ");
                insuranceLabel.setHorizontalAlignment(4);
                add(insuranceLabel);

                insuranceTextField = new JTextField(patient.getInsuranceCompany());
                add(insuranceTextField);
            }
            catch(Exception e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            }
        }

        public void fillNurseCombobox(ArrayList<String> nursesList) {
            for(String nurse : nursesList) {
                nurseCB.addItem(nurse);
            }
        }
    }

    public class titlePatientPanel extends JPanel{

        private Patient patient;
        private JLabel title;

        public titlePatientPanel(Patient patient){
            this.patient = patient;
            setBackground(Color.LIGHT_GRAY);
            setLayout(new FlowLayout());

            title = new JLabel("Patient : " + patient.getLastName() + " " + patient.getFirstName() + " (ID : " + patient.getId() +")");
            title.setFont(new Font(Font.DIALOG,Font.BOLD,20));
            add(title);
        }
    }

    public class RadioButtonPatientPanel extends JPanel {
        private JRadioButton canLeave, cannotLeave;
        private ButtonGroup buttonGroup;

        public RadioButtonPatientPanel(Patient patient){
            setLayout(new FlowLayout(FlowLayout.LEFT));
            canLeave = new JRadioButton("Oui", patient.getCanLeave());
            cannotLeave = new JRadioButton("Non", !patient.getCanLeave());
            add(canLeave);
            add(cannotLeave);
            buttonGroup = new ButtonGroup();
            buttonGroup.add(canLeave);
            buttonGroup.add(cannotLeave);
        }
    }

    public class ButtonPatientPanel extends JPanel {

        private JButton saveChanges;
        private Container mainContainer;

        public ButtonPatientPanel(Container mainContainer){
            setBackground(Color.LIGHT_GRAY);
            this.mainContainer = mainContainer;

            setLayout(new FlowLayout());
            saveChanges = new JButton("Sauvegarder");
            add(saveChanges);

            add(new BackButton(mainContainer));
        }
    }

}
